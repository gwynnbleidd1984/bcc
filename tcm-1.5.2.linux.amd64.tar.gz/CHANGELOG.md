# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

### Changed

### Fixed

## [1.5.2] - 2025-10-22

The release fixes bugs.

### Added

### Changed

### Fixed

- `roles`: prevent empty permissions when creating role 
  [#TNTP-4388](https://jira.vk.team/browse/TNTP-4388).

## [1.5.1] - 2025-09-17

The release fixes bugs.

### Added

- `migration` : added a new Migrations section with a Duration field. 
  Allows setting the maximum execution time for long-running migrations,
  preventing them from being interrupted by the default timeout (#TNTP-2342).

### Changed

### Fixed

- `utils` : fix FilterSlices function to filter slices.

## [1.5.0] - 2025-08-28

The release improves TCF configuration settings page and fixes bugs.

### Added

- Implemented a UI settings page for configuring TCF cluster parameters
  with support for retrieving and editing the following fields (#TNTP-1501):
  - `dml_users`: list of DML users
  - `cluster1`, `cluster2`: cluster settings
  - `replication_user`: replication credentials
  - `replication_password`: replication credentials
  - `failover_timeout`: failover switch timeout
  - `initial_status`: initial service state
  - `max_suspect_counts`: maximum number of suspect counts for failover
  - `health_check_delay`: delay between health checks
  - `enable_system_check`: enable or disable system health checks
  - `status_ttl`: time-to-live for service status

### Changed

- `test`: replaced time.Sleep with require.Eventually
  and efficient HTTP and tuple insertion checks (#TNTP-3612).

### Fixed

- `crud/explorer`: corrected data types in the CRUD and Explorer
  modules during operations to comply with FSTEC requirements,
  ensuring strict typing and information security (#TNTP-2627).
- `auth`: replace etcd with local config for auth (#TNTP-3688).
- `log`: fixed log output to `slog` (#TNTP-3222).
- `tuples`: fixed tab refresh error if cluster has a lot of spaces (#TNTP-3693).
- `frontend`: fix UI issues in OperationStatus component view (#TNTP-4110).

## [1.4.0] - 2025-06-09

The release improves LDAP support.

### Added

- `ldap` Implemented a popup notification with visual confirmation
   upon successful LDAP server connection (#TNTP-2629).
- `auth` Add UI support for switching between local and LDAP 
  authentication methods (#TNTP-2630).

### Changed

- Simplified field validation for LDAP configuration:  
  - `groupQueryTemplate` is now optional (supports authentication without
    groups),
  - `queryUser` and `queryPassword` are now optional (allows anonymous access), 
  - Only one of `templateDN` or `templateQuery` is required (previously both
    were mandatory) (#TNTP-2628).

### Fixed

- `auditlog`: changed the creation of a file for logs in the directory
  with the binary of the running application (#TNTP-2117).
- `etcd`: fixed etcd-client connection freezes if any node from
  the `etcd` cluster hangs with an opened port (#TNTP-1828).

## [1.3.1] - 2025-04-15

The release updates the frontend part, which we forgot to update in the
previous release, and contains fixes for a Svacer linter issues.

### Fixed

- The frontend was not updated due to a mistake in internal
  processes.

## [1.3.0] - 2025-03-14

The release improves TCF page and fixes non-critical bugs.

### Added

- Disable TCF page by default (#1596, #1597).
- TQE ability to connect to multiple grps servers (#1600, #1601).
- Explorer changed pagination from a tuple to a pointer (#1611).
- Add `demote` call for on TCF page (#TNTP-1106, #TNTP-1105).
- Add `promote` call for on TCF page (#TNTP-1104, #TNTP-1107).

### Fixed

- Explorer when sending to the frontend, we encode varbinary in base64 (#1580).
- Tabs that use `etсd` for updating cannot be refreshed if any of the
  `etcd` endpoints are unavailable (#1626).
- Added check for presence of elements in tuple array to prevent errors
  when processing empty data.
- Test for crud/explorer query and error handling when parsing the search
  expression (#1630).
- Explorer/CRUD fix error `Supplied key type of part 1 does not match index
  part type: expected datetime` (#TNTP-1265).

## [1.2.3] - 2024-11-07

### Fixed

- Big tuples on view page

## [1.2.2] - 2024-10-09

### Added

- Tarantool Cluster Federation page

### Fixed

- Various timeout issues

## [1.2.1] - 2024-08-12

### Added

- New cluster issues (time difference and high ping time)
- Tarantool schema migrations

### Fixed

- Cluster issues sorting
- Tarantool config storage watchers

## [1.2.0] - 2024-06-30

### Added

- Tarantool user control screen
- Console command Add/Delete cluster
- Added initial settings to tcm.yml config (ability to add clusters via tcm config file)
- Add configuration key for api token enabling

## [1.1.0] - 2024-05-15

## Added

- API token access
- Access Control List for spaces and stored functions
- Stateful failover and switchover controls
- Schema editor
- Instance space explorer
- CRUD explorer
- Stored functions editor
- Cluster metrics
- TT-based web terminal
- Slab info treemap visualization
- SQL execution panel
- Grouping instances by user query
- Hover functionality to language server protocol
- Basic onboarding tutorial
- Stateboard runtime issues
- Additional validations (anomalies) in cluster config
    - Count of users, nullable password
    - Leader existence
    - Count of active replicas
    - etc

## [1.0.4] - 2024-01-30

Internal release

## [1.0.3] - 2024-01-29

### Fixed

- Crash when cluster.storage replicaset degradation and no auditlog object constructed

## [1.0.2] - 2024-01-27

### Fixed

- Config.storage commit call using pool.RW
- Storing cluster tarantool connection password
- Fix config.info watcher deserialisation

## [1.0.1] - 2024-01-26

### Added

- New option storage.tarantool.addrs to support tarantool config.storage replicaset
- Command to resign data when changing the private key for admin

## [1.0.0] - 2023-12-26

### Added

- Cluster Stateboard with Leader Promotion and Instance Terminal
- etcd-based Centralized Cluster Configuration
- Role Based Access Control
- LDAP
- Auditlog
