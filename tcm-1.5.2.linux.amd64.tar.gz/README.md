# tarantool-cluster-manager

Tarantool Cluster Manager is webUI interface for Tarantool 3.0 with centralized config using etcd.

## Pre-requisites

- tarantool enterprise >= 3.0

## Configuration

There are 3 ways to configure TCM
- env variables
- dot env file (see `.env.example`)
- command line (see `./tcm --help`)

## Monitoring

### TCM Metrics

- default prometheus endpoint `/metrics` (see `./tcm --help`)

## First steps

- Setup one node etcd
```
etcd
```
- Run tcm
```
./tcm
```
- See bootstrap admin user password in logs
- Open http://127.0.0.1:8080 on browser
- Log In with user:
  - admin
  - generated password from logs
- Go to `Config` page
- Create new file `all`
- Insert cluster topology 
```
credentials:
  users:
    guest:
      roles: [super]

groups:
  group-001:
    replicasets:
      replicaset-001:
        instances:
          instance-001:
            iproto:
              listen: 
                - uri: '127.0.0.1:3301'
              advertise:
                client: '127.0.0.1:3301'
```
- Run Tarantool instance
```
export TT_INSTANCE_NAME=instance-001
export TT_CONFIG_ETCD_ENDPOINTS="http://127.0.0.1:2379"
export TT_CONFIG_ETCD_PREFIX=/default
tarantool
```
- Go to Stateboard
